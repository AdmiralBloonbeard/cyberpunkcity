function setup() {
  createCanvas(400, 400);
  background(135, 206, 235); // Sky blue background
  drawForest();
}

function drawForest() {
  // Ground - valley viewed from hilltop
  noStroke();
  fill(34, 139, 34); // Forest green
  beginShape();
  vertex(0, height * 0.3); // Left hilltop edge
  vertex(150, height * 0.6); // Left valley slope
  vertex(200, height * 0.8); // Valley bottom
  vertex(250, height * 0.6); // Right valley slope
  vertex(width, height * 0.3); // Right hilltop edge
  vertex(width, height);
  vertex(0, height);
  endShape(CLOSE);

  // White-grayish elements (rocks or snow patches) on hills
  fill(200, 200, 200); // Light gray
  ellipse(50, height * 0.4, 30, 20); // Left hill rock
  ellipse(350, height * 0.4, 30, 20); // Right hill rock

  // Sun in the sky
  fill(255, 223, 0); // Yellow sun
  ellipse(width * 0.9, height * 0.1, 50, 50);

  // Draw trees in the valley
  for (let i = 0; i < 15; i++) {
    let x = random(150, 250); // Valley center
    let y = random(height * 0.6, height * 0.8); // Valley floor
    drawTree(x, y);
  }

  // Add some grass patches on hills
  for (let i = 0; i < 20; i++) {
    let x = random(0, width);
    let y = random(height * 0.3, height * 0.6);
    drawGrass(x, y);
  }
}

function drawTree(x, y) {
  // Tree trunk
  fill(139, 69, 19); // Brown for trunk
  rect(x - 10, y - 40, 20, 40);

  // Tree foliage - upside-down pie slice (triangle-like cartoon style)
  fill(50, 168, 82); // Green for leaves
  beginShape();
  vertex(x, y - 70); // Top point
  vertex(x - 30, y - 20); // Left base
  vertex(x + 30, y - 20); // Right base
  endShape(CLOSE);
}

function drawGrass(x, y) {
  fill(124, 252, 0); // Lighter green for grass
  noStroke();
  triangle(x, y, x - 5, y + 10, x + 5, y + 10); // Small grass blade
}